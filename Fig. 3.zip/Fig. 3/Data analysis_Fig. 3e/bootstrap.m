clc;
clear all
data=readmatrix("ATT0_Cy3_Cy5.xlsx");%change file name
column=1; %change this

number_of_simulated_sample=1000;
bootstrapdata=zeros([size(data,1) number_of_simulated_sample]);
bootstrapdata(:,1)=data(:,column);
for i=2:1:number_of_simulated_sample+1
    for j=1:1:size(data,1)
        index=randi(size(data,1));
        bootstrapdata(j,i)=data(index,column);
    end
end

withring=mean(bootstrapdata);
average=mean(withring)
stdev=std(withring)